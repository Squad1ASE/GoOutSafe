class Table:

    def __init__(self, name, capacity):
        self.name = name
        self.capacity = capacity
